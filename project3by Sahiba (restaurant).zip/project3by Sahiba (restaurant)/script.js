const themeBtn = document.getElementById('themeBtn');
const counterDisplay = document.getElementById('counterDisplay');
const incrementBtn = document.querySelector('.js-increment');
const resetBtn = document.querySelector('.js-reset');

let orderCount = 0;

themeBtn.addEventListener('click', function () {
  document.body.classList.toggle('is-dark');
  document.body.classList.toggle('is-light');

  if (document.body.classList.contains('is-light')) {
    themeBtn.textContent = '🌙 Dark';
  } else {
    themeBtn.textContent = '☀️ Light';
  }
});

function toggleCard(card) {
  card.classList.toggle('is-open');
}

function addOrder(event) {
  // Card click se order button alag karo
  event.stopPropagation();

  const btn = event.target;

  if (btn.classList.contains('is-added')) {
    // Agar already added hai toh remove karo
    btn.textContent = 'Order Now';
    btn.classList.remove('is-added');
    orderCount--;
  } else {
    // Add karo
    btn.textContent = '✔ Added!';
    btn.classList.add('is-added');
    orderCount++;
  }

  counterDisplay.textContent = orderCount;
}

incrementBtn.addEventListener('click', function () {
  orderCount++;
  counterDisplay.textContent = orderCount;
});

resetBtn.addEventListener('click', function () {
  orderCount = 0;
  counterDisplay.textContent = orderCount;

  const allOrderBtns = document.querySelectorAll('.order-btn');
  allOrderBtns.forEach(function (btn) {
    btn.textContent = 'Order Now';
    btn.classList.remove('is-added');
  });
});

function toggleFaq(question) {
  const answer = question.nextElementSibling;

  // Pehle saare band karo
  document.querySelectorAll('.faq-question').forEach(function (q) {
    q.classList.remove('is-open');
    q.nextElementSibling.classList.remove('is-open');
  });

  if (!answer.classList.contains('is-open')) {
    question.classList.add('is-open');
    answer.classList.add('is-open');
  }
}